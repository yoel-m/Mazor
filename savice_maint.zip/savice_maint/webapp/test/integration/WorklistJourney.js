/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"sap/ui/Device",
	"./pages/Worklist"
], function (opaTest, Device) {
	"use strict";

	QUnit.module("Worklist");



});