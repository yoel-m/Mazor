sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel",
    "../model/MainService", 
    'sap/m/MessageToast',
    "sap/m/library"
], function (Controller, UIComponent,JSONModel, MainService,MessageToast, mobileLibrary) {
    "use strict";

    // shortcut for sap.m.URLHelper
    var URLHelper = mobileLibrary.URLHelper;

    return Controller.extend("moh.gov.il.savicemaint.controller.BaseController", {
        /**
         * Convenience method for accessing the router.
         * @public
         * @returns {sap.ui.core.routing.Router} the router for this component
         */
        getRouter : function () {
            return UIComponent.getRouterFor(this);
        },

        /**
         * Convenience method for getting the view model by name.
         * @public
         * @param {string} [sName] the model name
         * @returns {sap.ui.model.Model} the model instance
         */
        getModel : function (sName) {
            return this.getView().getModel(sName);
        },

        /**
         * Convenience method for setting the view model.
         * @public
         * @param {sap.ui.model.Model} oModel the model instance
         * @param {string} sName the model name
         * @returns {sap.ui.mvc.View} the view instance
         */
        setModel : function (oModel, sName) {
            return this.getView().setModel(oModel, sName);
        },

        /**
         * Getter for the resource bundle.
         * @public
         * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
         */
        getResourceBundle : function () {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },

        /**
         * Event handler when the share by E-Mail button has been clicked
         * @public
         */
        onShareEmailPress : function () {
            var oViewModel = (this.getModel("objectView") || this.getModel("worklistView"));
            URLHelper.triggerEmail(
                null,
                oViewModel.getProperty("/shareSendEmailSubject"),
                oViewModel.getProperty("/shareSendEmailMessage")
            );
        },
        fillSelectList: function(entity) {
            return new Promise((resolve, reject) => {
                const oCtrl = this;
                const oService = new MainService(this.getView(), false);
                let getItms = oService.getEntitySet(entity);
        
                getItms
                    .then(function (oODataResult) {
                        if ((oODataResult) && (oODataResult.oData)) {
                            sap.ui.core.BusyIndicator.hide();
        
                            if (
                                oODataResult.oResponse.statusCode == "200" ||
                                oODataResult.oResponse.statusCode === "201" ||
                                oODataResult.oResponse.statusCode === "202" ||
                                oODataResult.oResponse.statusCode == "0"
                            ) {
                                let oModel = new JSONModel(oODataResult.oData.results);
                                resolve(oModel); 
                            } else {
                                reject(`Status Code ${oODataResult.oResponse.statusCode}`); // Reject the promise with an error message
                            }
                        } else {
                            reject("No Data"); 
                        }
                    }.bind(oCtrl))
                    .catch(function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show(oError.message);
                        reject(oError); // Reject the promise with the error object
                    }.bind(oCtrl));
            });
        },

        fillSelectListRelated: function(fromEntity, parm, toEntity) {
            return new Promise((resolve, reject) => {
                const oCtrl = this;
                const oService = new MainService(this.getView(), false);
                let getItms = oService.getRelatedEntitySet(fromEntity, parm, toEntity);
        
                getItms.then(function (oODataResult) {
                        if ((oODataResult) && (oODataResult.oData)) {
                            sap.ui.core.BusyIndicator.hide();
        
                            if (
                                oODataResult.oResponse.statusCode == "200" ||
                                oODataResult.oResponse.statusCode === "201" ||
                                oODataResult.oResponse.statusCode === "202" ||
                                oODataResult.oResponse.statusCode == "0"
                            ) {
                                let oModel = new JSONModel(oODataResult.oData.results);
                                resolve(oModel); 
                            } else {
                                reject(`Status Code ${oODataResult.oResponse.statusCode}`); // Reject the promise with an error message
                            }
                        } else {
                            reject("No Data"); 
                        }
                    }.bind(oCtrl))
                    .catch(function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show(oError.message);
                        reject(oError); // Reject the promise with the error object
                    }.bind(oCtrl));
            });
        },        

    });

});