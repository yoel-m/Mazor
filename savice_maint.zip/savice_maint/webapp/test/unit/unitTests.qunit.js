/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"moh/gov/il/savicemaint/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});