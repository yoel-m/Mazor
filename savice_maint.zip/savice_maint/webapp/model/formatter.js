sap.ui.define([], function () {
    "use strict";

    return {

        /**
         * Rounds the number unit value to 2 digits
         * @public
         * @param {string} sValue the number string to be rounded
         * @returns {string} sValue with 2 digits rounded
         */
        numberUnit : function (sValue) {
            if (!sValue) {
                return "";
            }
            return parseFloat(sValue).toFixed(2);
        },

        msJsonDateFormatter: function (msJsonDate) {
            if (typeof msJsonDate === 'object') {
                var day = msJsonDate.getDate();
                var month = msJsonDate.getMonth() + 1; // Months are 0-based, so add 1
                var year = msJsonDate.getFullYear();

                // Format the date with leading zeros
                var formattedDate = (day < 10 ? '0' : '') + day + '/' + (month < 10 ? '0' : '') + month + '/' + year;

                return formattedDate;
            
            }
            return null; // Return null for invalid input
        },
      
   
          

    };

});