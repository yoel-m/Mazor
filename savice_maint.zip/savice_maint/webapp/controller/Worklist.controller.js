sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/ui/model/Filter",
    "../model/MainService", 
    "sap/ui/model/FilterOperator",
    'sap/ui/model/SimpleType',
    'sap/m/MessageBox',
    'sap/m/MessageToast',
    'sap/ui/model/ValidateException'
], function (BaseController, JSONModel, formatter, Filter,MainService, FilterOperator,SimpleType,MessageBox,MessageToast,ValidateException) {
    "use strict";

    return BaseController.extend("moh.gov.il.savicemaint.controller.Worklist", {

        formatter: formatter,

        onInit : function () {

            var oUriParameters = jQuery.sap.getUriParameters();
            var paramValue = oUriParameters.get("sap-language");
            

            var oViewModel;

            this.oView.setModel(new JSONModel({
				name : "",
				email : ""
			}));

            oViewModel = new JSONModel({
                worklistTableTitle : this.getResourceBundle().getText("worklistTableTitle"),
                shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
                shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
                tableNoDataText : this.getResourceBundle().getText("tableNoDataText")
            });
            this.setModel(oViewModel, "worklistView");
            sap.ui.getCore().getMessageManager().registerObject(this.oView.byId("emailInput"), true);
            this.getOwnerComponent().getRouter().getRoute("worklist").attachPatternMatched(this._onMasterMatched, this);

        },

        _onMasterMatched :  function() {
         

            //================================================
            //    Screen mode
            //================================================



            var oUriParameters = jQuery.sap.getUriParameters();
            var paramValue = oUriParameters.get("callType"); 

            var callTypeModel = new JSONModel ({type: paramValue}) ; 
            this.getView().setModel(callTypeModel, "callTypeModel");

            //debugger ; 

            //============================================================
            // בחר בר קוד
            //============================================================              

            if (this.getView().getModel("callTypeModel").getData().type == "R") {
                this.fillSelectList("BusinessPartnerSet")
                .then(function (oModel) {

                   
                    const objLocation = { ContactGuid: "-999", LastName: "בחר מיקום" };
                    let oMdlLocation = new JSONModel([objLocation]);
                    var oSelectLocation = this.byId('locationDDL');
                    oSelectLocation.setModel(oMdlLocation, "selectLocationModel"); 
                    oSelectLocation.setSelectedKey("-999");
                 
                    const obj = { BusinessPartnerID: "-999", CompanyName: "בחר ברקוד" };
                    let oData = oModel.getData();
                    oData.push(obj);
                    oModel.setData(oData);
                    oModel.setSizeLimit(1000);
                    var oSelect = this.byId('barCodeDDL');
                    oSelect.setModel(oModel, "selectBarcodeModel"); 
                    oSelect.addEventDelegate({
                        onAfterRendering: function() {
                            oSelect.setSelectedKey("-999");
                        }
                    });
                }.bind(this))
                .catch(function (error) {
                    console.log(error);
                });    
            }           

            
            //============================================================
            // בחר מיקום
            //============================================================        
            if (this.getView().getModel("callTypeModel").getData().type != "R") {
                this.fillSelectList("ContactSet")
                .then(function (oModel) {
                    const obj = { ContactGuid: "-999", LastName: "בחר מיקום" };
                    let oData = oModel.getData();
                    oData.push(obj);
                    oModel.setData(oData);
                    oModel.setSizeLimit(1000);
                    var oSelect = this.byId('locationDDL');
                    oSelect.setModel(oModel, "selectLocationModel"); 
                    oSelect.addEventDelegate({
                        onAfterRendering: function() {
                            oSelect.setSelectedKey("-999");
                        }
                    });
                }.bind(this))
                .catch(function (error) {
                    console.log(error);
                });    
            }else {
                this.fillSelectList("ContactSet")
                .then(function (oModel) {
                    const obj = { ContactGuid: "-999", LastName: "בחר מחלקה מזמינה" };
                    let oData = oModel.getData();
                    oData.push(obj);
                    oModel.setData(oData);
                    oModel.setSizeLimit(1000);
                    var oSelect = this.byId('departmentDDL');
                    oSelect.setModel(oModel, "departmentModel"); 
                    oSelect.addEventDelegate({
                        onAfterRendering: function() {
                            oSelect.setSelectedKey("-999");
                        }
                    });
                }.bind(this))
                .catch(function (error) {
                    console.log(error);
                });    

            }
            //=======================================================
            // בחר גורם מטפל
            //============================================================
          
            this.fillSelectList("ProductSet")
            .then(function (oModel) {
                const obj = { ProductID: "-999", Name: "בחר גורם מטפל" };
                let oData = oModel.getData();
                oData.push(obj);
                oModel.setData(oData);
                oModel.setSizeLimit(1000);
                var oSelect = this.byId('factorHandlerDDL');
                oSelect.setModel(oModel, "factorHandlerModel"); 
                oSelect.addEventDelegate({
                    onAfterRendering: function() {
                        oSelect.setSelectedKey("-999");
                    }
                });
            }.bind(this))
            .catch(function (error) {
                console.log(error);
            });  

            //============================================================
            // בחר קוד תקלה
            //============================================================
 
            const obj = { SalesOrderID: "-999", Note: "בחר קוד תקלה" };
            let oMdl1 = new JSONModel([obj]);
            this.getView().setModel(oMdl1, "caseCodeModel");
            var oSelect1 = this.byId('caseCodeDDL');
            oSelect1.addEventDelegate({
                onAfterRendering: function() {
                    oSelect1.setSelectedKey("-999");
                }
            });
            


                /*
            const obj = { Key: "-999", Note: "בחר גורם מטפל" };
            let oMdl1 = new JSONModel([obj]);
            this.getView().setModel(oMdl1, "factorHandler");
            var oSelect1 = this.byId('factorHandlerDDL');
            oSelect1.addEventDelegate({
                onAfterRendering: function() {
                    oSelect1.setSelectedKey("-999");
                }
            });
                        
            this.fillSelectList("SalesOrderSet")
            .then(function (oModel) {
                this.getView().setModel(oModel, "selectedList3");
            }.bind(this))
            .catch(function (error) {
                console.log(error) ; 
            });
            */


            let oModel = new JSONModel({cd:this.getFormattedCurrentDate()}); 
            this.getView().setModel (oModel,"currentDate")
        },

        selectFactorHandlerDDL : function(evt) {
          //  debugger; 
            let selectedKey = this.byId('factorHandlerDDL').getSelectedKey() ; 
            if (  selectedKey != "-999" ) {
                this.fillSelectListRelated("ProductSet", selectedKey, "ToSalesOrderLineItems" )
                .then(function (oModel) {
                    this.getView().setModel(oModel, "caseCodeModel");       
                }.bind(this))
                .catch(function (error) {
                    console.log(error) ; 
                });                      
            }
        },

        selectBarcodeDDL : function(evt) {
            //  debugger; 
              let selectedKey = this.byId('barCodeDDL').getSelectedKey() ; 
              if (  selectedKey != "-999" ) {
                  this.fillSelectListRelated("BusinessPartnerSet", selectedKey, "ToContacts" )
                  .then(function (oModel) {        
                   // const obj = { ContactGuid: "-999", LastName: "בחר מיקום" };
                   // oModel.getData().push(obj);
                    var oSelect = this.byId('locationDDL');
                    oSelect.setModel(oModel, "selectLocationModel");                                                   
                  }.bind(this))
                  .catch(function (error) {
                      console.log(error) ; 
                  });                      
              }
          },

        /*
        fillSelectList: function (entity , modelName ) {

			const oCtrl = this;
			const oService = new MainService(this.getView(),false);		
			let getItms = oService.setSelectList(entity); 
			 
			getItms.then(function(oODataResult) {
				if ((oODataResult) && (oODataResult.oData)) {
					sap.ui.core.BusyIndicator.hide();
	
					if (oODataResult.oResponse.statusCode == "200" ||
					   (oODataResult.oResponse.statusCode === "201") ||
					   (oODataResult.oResponse.statusCode === "202") ||
					   (oODataResult.oResponse.statusCode == "0")
						
					) { 										 
						let oModel =   new JSONModel(oODataResult.oData.results); 
                        this.getView().setModel (oModel,modelName);
                      
					} else {
						MessageToast.show(`Status Code ${oODataResult.oResponse.statusCode}`);
					}
				} else {
					MessageToast.show("No Data");
				}}.bind(oCtrl))
			.catch(function(oError) {
				sap.ui.core.BusyIndicator.hide();
				{
					MessageToast.show(oError.message);
				}
			}.bind(oCtrl)) ;  	 

        }, 
        */
        getFormattedCurrentDate: function (){

            const currentDate = new Date();

            const day = currentDate.getDate();
            const month = currentDate.getMonth() + 1;  
            const year = currentDate.getFullYear();

            const formattedDay = String(day).padStart(2, '0');
            const formattedMonth = String(month).padStart(2, '0');

            const formattedDate = `${formattedDay}/${formattedMonth}/${year}`;

            return formattedDate;
        },

        /**
         * Event handler when a table item gets pressed
         * @param {sap.ui.base.Event} oEvent the table selectionChange event
         * @public
         */
        onPress : function (oEvent) {
            // The source is the list item that got pressed
            this._showObject(oEvent.getSource());
        },

        /**
         * Event handler for navigating back.
         * Navigate back in the browser history
         * @public
         */
        onNavBack : function() {
            // eslint-disable-next-line fiori-custom/sap-no-history-manipulation, fiori-custom/sap-browser-api-warning
            history.go(-1);
        },


        onSearch : function (oEvent) {
            if (oEvent.getParameters().refreshButtonPressed) {
                // Search field's 'refresh' button has been pressed.
                // This is visible if you select any main list item.
                // In this case no new search is triggered, we only
                // refresh the list binding.
                this.onRefresh();
            } else {
                var aTableSearchState = [];
                var sQuery = oEvent.getParameter("query");

                if (sQuery && sQuery.length > 0) {
                    aTableSearchState = [new Filter("SalesOrderID", FilterOperator.Contains, sQuery)];
                }
                this._applySearch(aTableSearchState);
            }

        },

        /**
         * Event handler for refresh event. Keeps filter, sort
         * and group settings and refreshes the list binding.
         * @public
         */
        onRefresh : function () {
            var oTable = this.byId("table");
            oTable.getBinding("items").refresh();
        },

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

        /**
         * Shows the selected item on the object page
         * @param {sap.m.ObjectListItem} oItem selected Item
         * @private
         */
        _showObject : function (oItem) {
            this.getRouter().navTo("object");
        },
		onChangeEmail: function(oEvent) {
			var that = this;
			var oView = this.getView();
			var aInputs = oView.byId("emailInput") ; 
	 
			var bValidationError = false;
			bValidationError = that._validateInput(aInputs)  ;
		

			/*
			if (!bValidationError) {
				MessageToast.show("The input is validated. You could now continue to the next screen");
			} else {
				MessageBox.alert("A validation error has occured. Complete your input first");
			}*/
		},
		_validateInput: function(oInput) {
			var oBinding = oInput.getBinding("value");
			var sValueState = "None";
			var bValidationError = false;

			try {
				oBinding.getType().validateValue(oInput.getValue());
			} catch (oException) {
				sValueState = "Error";
				bValidationError = true;
			}

			oInput.setValueState(sValueState);

			return bValidationError;
		},


		customEMailType : SimpleType.extend("email", {
			formatValue: function (oValue) {
				return oValue;
			},
			parseValue: function (oValue) {
				//parsing step takes place before validating step, value could be altered here
				return oValue;
			},
			validateValue: function (oValue) {
				// The following Regex is NOT a completely correct one and only used for demonstration purposes.
				// RFC 5322 cannot even checked by a Regex and the Regex for RFC 822 is very long and complex.
				var rexMail = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
				if (!oValue.match(rexMail)) {
					throw new ValidateException("'" + oValue + "' לא כתובת תקנית");
				}
			}
		}),


        /**
         * Internal helper method to apply both filter and search state together on the list binding
         * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
         * @private
         */
        _applySearch: function(aTableSearchState) {
            var oTable = this.byId("table"),
                oViewModel = this.getModel("worklistView");
            oTable.getBinding("items").filter(aTableSearchState, "Application");
            // changes the noDataText of the list in case there are no filter results
            if (aTableSearchState.length !== 0) {
                oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
            }
        }

    });
});
