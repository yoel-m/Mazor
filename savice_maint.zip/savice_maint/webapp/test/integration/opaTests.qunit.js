/* global QUnit */

sap.ui.require([
	"moh/gov/il/savicemaint/test/integration/AllJourneys"
], function() {
	QUnit.config.autostart = false;
	QUnit.start();
});